//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CPort"
#pragma link "CPortCtl"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
int i=0,val;
AnsiString s="";
if(ComPort1->InputCount()!=0){
i=ComPort1->InputCount();
ComPort1->ReadStr(s,i);
//val = s.ToInt();
/*
if(val > 700) {
    Memo1->Lines->Add("Boom! 700");
}
*/
Memo1->Lines->Add(s);
}

}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
ComPort1->ShowSetupDialog();
ComPort1->Connected = true;
Timer1->Enabled = true;
}
//---------------------------------------------------------------------------

